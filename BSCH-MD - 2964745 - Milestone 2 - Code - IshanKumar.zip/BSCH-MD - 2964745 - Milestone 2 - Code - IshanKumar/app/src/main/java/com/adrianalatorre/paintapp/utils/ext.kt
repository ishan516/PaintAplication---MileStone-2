package com.adrianalatorre.paintapp.utils

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

/*
*
* Vibrator wrapper class
* 400L = Vibrate length in milliseconds
*
* */
fun vibrate(mContext: Context){
    val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        (mContext.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    } else {
        mContext.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }


    if (Build.VERSION.SDK_INT >= 26) {
        vibrator.vibrate(
            VibrationEffect.createOneShot(
                400L,
                VibrationEffect.DEFAULT_AMPLITUDE
            )
        )
    } else {
        vibrator.vibrate(400L)
    }
}