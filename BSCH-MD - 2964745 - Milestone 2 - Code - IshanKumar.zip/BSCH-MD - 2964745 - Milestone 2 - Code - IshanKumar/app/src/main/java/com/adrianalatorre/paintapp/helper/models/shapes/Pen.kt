package com.adrianalatorre.paintapp.helper.models.shapes

import android.graphics.Paint
import android.graphics.PointF

import com.adrianalatorre.paintapp.helper.models.PaintBrush
import com.adrianalatorre.paintapp.helper.models.PaintCanvas
import com.adrianalatorre.paintapp.helper.models.Tool

open class Pen internal constructor(paintBrush: PaintBrush) : Tool(paintBrush) {

    override fun paint(canvas: PaintCanvas) {
        paintBrush.style = Paint.Style.STROKE
        paintBrush.color = paintBrush.strokeColor
        paintBrush.strokeWidth = paintBrush.size.toFloat()
        canvas.drawPath(this, paintBrush)
    }

    override fun draw(i: PointF, f: PointF) {
        this.lineTo(f.x, f.y)
    }
}
