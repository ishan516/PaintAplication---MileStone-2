package com.adrianalatorre.paintapp.helper.models.shapes

import android.graphics.PointF

import com.adrianalatorre.paintapp.helper.models.PaintBrush
import com.adrianalatorre.paintapp.helper.models.Tool

class Quad2D internal constructor(paintBrush: PaintBrush) : Tool(paintBrush) {

    override fun draw(i: PointF, f: PointF) {
        this.reset()
        this.moveTo(i.x, i.y)
        this.lineTo(i.x, f.y)
        this.lineTo(f.x, f.y)
        this.lineTo(f.x, i.y)
        this.lineTo(i.x, i.y)
    }
}
