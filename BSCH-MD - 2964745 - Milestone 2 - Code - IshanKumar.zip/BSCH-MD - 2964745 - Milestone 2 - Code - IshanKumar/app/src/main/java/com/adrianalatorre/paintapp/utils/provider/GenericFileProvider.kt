package com.adrianalatorre.paintapp.utils.provider

import androidx.core.content.FileProvider

/*
*
* Legacy Custom file provider for Android 11 >=
*
* */
class GenericFileProvider : FileProvider()