package com.adrianalatorre.paintapp.utils

import android.content.Context
import com.adrianalatorre.paintapp.MyApplication.Companion.EXT_IMAGE
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

object FileUtils {

    /**
     * Creates an empty JPG file in the default Pictures directory, using the given name.
     *
     * @param [context] this is used to get the default Pictures directory.
     * @param [name] name of the empty file to create.
     * @return a file object corresponding to a newly-created file.
     *
     * @throws IOException in case of input/output error.
     */
    @Throws(IOException::class)
    fun createImageFile(context: Context, name: String): File {
        val dir = context.filesDir
        val filename = dir?.toString() + File.separator + name + EXT_IMAGE

        val tempFile = File(filename)
        tempFile.createNewFile()

        return tempFile
    }

    @Throws(IOException::class)
    fun writeToFile(bytes: ByteArray, file: File) {
        val out = FileOutputStream(file)
        out.write(bytes)
        out.flush()
        out.close()
    }

}