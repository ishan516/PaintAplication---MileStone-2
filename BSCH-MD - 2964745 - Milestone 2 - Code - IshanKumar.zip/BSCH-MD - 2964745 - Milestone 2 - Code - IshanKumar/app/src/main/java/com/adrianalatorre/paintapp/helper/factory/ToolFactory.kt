package com.adrianalatorre.paintapp.helper.factory

import com.adrianalatorre.paintapp.helper.models.PaintBrush
import com.adrianalatorre.paintapp.helper.models.Tool

/*
*
* A singleton factory class for painting function tools
*
* */
object ToolFactory {

    operator fun get(type: Class<out Tool>, paintBrush: PaintBrush): Tool? {
        var tool: Tool? = null
        try {
            val ctor = type.getDeclaredConstructor(PaintBrush::class.java)
            tool = ctor.newInstance(paintBrush)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return tool
    }

}
