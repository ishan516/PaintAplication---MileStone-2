package com.adrianalatorre.paintapp.helper.models.shapes

import android.graphics.Paint

import com.adrianalatorre.paintapp.helper.models.PaintBrush
import com.adrianalatorre.paintapp.helper.models.PaintCanvas

class Eraser internal constructor(paintBrush: PaintBrush) : Pen(paintBrush) {

    fun initEraser(canvas: PaintCanvas) {
        paintBrush.strokeColor = canvas.color
    }

    override fun paint(canvas: PaintCanvas) {
        paintBrush.style = Paint.Style.STROKE
        paintBrush.color = canvas.color
        paintBrush.strokeWidth = paintBrush.size * 2.5f
        canvas.drawPath(this, paintBrush)
    }
}
