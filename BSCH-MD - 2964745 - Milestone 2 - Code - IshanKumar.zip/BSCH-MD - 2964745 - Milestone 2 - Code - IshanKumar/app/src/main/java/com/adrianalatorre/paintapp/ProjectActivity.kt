package com.adrianalatorre.paintapp

import android.content.Intent
import android.os.Bundle
import com.adrianalatorre.paintapp.R
import android.widget.ImageButton
import androidx.appcompat.app.AppCompatActivity
import com.adrianalatorre.paintapp.helper.ProjectInflater
import com.adrianalatorre.paintapp.utils.ThemeUtils

class ProjectActivity : AppCompatActivity() {

    private lateinit var composeButton: ImageButton
    private var projectInflater: ProjectInflater? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        // customize theme of activity
        ThemeUtils.setActivityTheme(this)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_project)

        setSupportActionBar(findViewById(R.id.toolbar))
        supportActionBar?.title = "${getString(R.string.app_name)}"

        // load all saved projects
        projectInflater = ProjectInflater(this)

        // Build floating actions
        composeButton = findViewById(R.id.compose_button)

        // open main activity to paint and create a project
        composeButton.setOnClickListener {
            val blankProjectIntent = Intent(this, MainActivity::class.java)
            startActivity(blankProjectIntent)
        }
    }

    override fun onResume() {
        super.onResume()
        // Inflate thumbnails of saved projects into UI Thread
        projectInflater?.let {
            runOnUiThread(it)
        }
    }

    override fun onBackPressed() {
        super@ProjectActivity.onBackPressed()
    }

    override fun startActivity(intent: Intent) {
        super.startActivity(intent)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

}