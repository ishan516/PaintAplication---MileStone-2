package com.adrianalatorre.paintapp

import android.annotation.SuppressLint
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Rect
import android.net.Uri
import com.adrianalatorre.paintapp.R
import android.os.Build.VERSION
import android.os.Build.VERSION_CODES
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.Menu
import android.view.MenuItem
import android.view.MotionEvent
import android.view.View
import android.widget.SeekBar
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.view.ContextThemeWrapper
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.core.graphics.BlendModeColorFilterCompat
import androidx.core.graphics.BlendModeCompat
import com.adrianalatorre.paintapp.MyApplication.Companion.FLAG_READ_ONLY
import com.adrianalatorre.paintapp.MyApplication.Companion.PROJECT_FROM_IMAGE
import com.adrianalatorre.paintapp.MyApplication.Companion.PROJECT_FROM_SAVED
import com.adrianalatorre.paintapp.MyApplication.Companion.PROPERTY_SUCCESS
import com.adrianalatorre.paintapp.helper.ActionBarManager
import com.adrianalatorre.paintapp.helper.factory.DialogFactory
import com.adrianalatorre.paintapp.helper.models.EyedropTool
import com.adrianalatorre.paintapp.helper.models.PaintCanvas
import com.adrianalatorre.paintapp.helper.models.shapes.*
import com.adrianalatorre.paintapp.helper.views.utils.ToolboxView
import com.adrianalatorre.paintapp.utils.BitmapUtils
import com.adrianalatorre.paintapp.utils.ProjectUtils
import com.adrianalatorre.paintapp.utils.ThemeUtils
import com.adrianalatorre.paintapp.utils.listener.OnColorPickedListener
import com.adrianalatorre.paintapp.utils.listener.OnToolSelectedListener
import com.adrianalatorre.paintapp.utils.vibrate
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity(), SeekBar.OnSeekBarChangeListener, OnToolSelectedListener,
    OnColorPickedListener, View.OnTouchListener {

    // Brush controller
    private var brushController: SeekBar? = null

    // A custom OpenGL ES canvas to draw on
    private lateinit var paintView: PaintView

    // Toolbox contains the drawing tools
    private lateinit var toolbox: ToolboxView

    // Action bars
    private lateinit var toolbar: CustomToolbar

    // maximizze or minize screen
    private var isMaximized: Boolean = false
        set(value) {
            field = value
            onToggleFullscreen(value)
        }

    private var stickyMaximized: Boolean = false

    // Is this a new or existing project?
    private var isExisting = false

    // Is the project opened in read-only mode?
    private var isViewing = false

    private var projectName: String? = null

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        ThemeUtils.setActivityTheme(this, true)
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // init custom toolbar
        this.toolbar = CustomToolbar()

        this.brushController = findViewById(R.id.brushController)
        this.brushController!!.setOnSeekBarChangeListener(this)

        // Obtain device display metrics (used to set up project resolution)
        var metrics = Rect()
        if (VERSION.SDK_INT >= VERSION_CODES.R) {
            metrics = windowManager.currentWindowMetrics.bounds
        } else {
            val displayMetrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getMetrics(displayMetrics)
            metrics.set(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels)
        }

        isViewing = intent.getBooleanExtra(FLAG_READ_ONLY, false)

        // Initialize canvas where everything is drawn
        paintView = findViewById(R.id.canvasView)
        paintView.setOnTouchListener(this)
        initPaintView(createCanvas(metrics))

        // Add click event listeners to toolbox buttons
        toolbox = findViewById(R.id.toolbox)

        this.onColorPicked(paintView.brush.strokeColor)
//        updatePenColorPicker(paintView.brush.strokeColor)

        //Event listen to detect when the shapes has been selected
        for (id in arrayOf(
            R.id.line, R.id.rect, R.id.triangle, R.id.circle,
            R.id.diamond, R.id.star, R.id.box
        )) {
            findViewById<View>(id)?.setOnClickListener { onToolSelected(false, id) }
        }

        //Event listen to detect when the colors has been selected
        for (id in arrayOf(R.id.blue, R.id.red, R.id.black)) {
            findViewById<View>(id)?.setOnClickListener {
                vibrate(this)
                onToolSelected(false, id)
            }
        }

        //Event listen to detect tool that has been selected
        findViewById<View>(R.id.selectedTool).setOnClickListener {
            // todo: findViewById<View>(R.id.brushSizeBar)?.visibility = View.VISIBLE
            onToolSelected(false, R.id.selectedTool)
        }
    }

    override fun onStart() {
        super.onStart()
        onToggleReadMode(isViewing)
    }

    override fun onResume() {
        super.onResume()
        paintView.invalidate()
    }

    override fun onBackPressed() {
        when {
            isViewing -> super.onBackPressed()
            paintView.isModified -> DialogFactory.confirmExitDialog(this,
                {
                    paintView.clear()
                    if (isExisting) {
                        super.onBackPressed()
                    } else {
//                        onToggleReadMode(true)
                        super.onBackPressed()
                    }
                },
                {
                    paintView.save()
                    if (isExisting) {
                        super.onBackPressed()
                    } else {
                        onToggleReadMode(true)
                    }
                })
                .show(supportFragmentManager)
            !isExisting -> super.onBackPressed()
            else -> onToggleReadMode(true)
        }
    }

    //color change listen
    override fun onColorPicked(color: Int) {
        // update paint color and status of paint canvas
        paintView.brush.strokeColor = color
        paintView.brush.fillColor = color
        updatePenColorPicker(color)

        paintView.canvas?.color = Color.WHITE
        paintView.invalidate()
    }

    // create and infalte main menu
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        if (!isMaximized) {
            val inflater = menuInflater
            inflater.inflate(R.menu.menu_main, menu)
            for (i in 0 until menu.size()) {
                menu.getItem(i)?.icon?.mutate()?.colorFilter =
                    BlendModeColorFilterCompat.createBlendModeColorFilterCompat(
                        ThemeUtils.colorTextPrimary(this),
                        BlendModeCompat.SRC_ATOP
                    )
            }

//            menu.findItem(R.id.canvas).isVisible = !isExisting

            val mActionBarManager = ActionBarManager(menu)
            paintView.setCanvasActionListener(mActionBarManager)
            mActionBarManager.sync(paintView)
        }

        return true
    }

    // top action bar item click callbacks
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (isViewing) return false
        when (item.itemId) {
            android.R.id.home -> {
                isMaximized = !isMaximized
                stickyMaximized = !stickyMaximized
            }

            R.id.undo -> {
                paintView.undo()
                return true
            }

            R.id.redo -> {
                paintView.redo()
                return true
            }

            R.id.revert -> {
                DialogFactory.confirmRevertDialog(this) {
                    paintView.clear()
                }.show(supportFragmentManager)
                return true
            }

            R.id.save -> {
                if (paintView.isModified) {
                    DialogFactory.confirmSaveDialog(this) {
                        paintView.save()
                        this@MainActivity.finish()
                    }.show(supportFragmentManager)
                }
                return true
            }
        }

        return false
    }

    //paint brush size controller
    override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
        if (seekBar == brushController) {
            paintView.brush.size = progress
        }
    }

    override fun onStartTrackingTouch(seekBar: SeekBar) {

    }

    override fun onStopTrackingTouch(seekBar: SeekBar) {

    }

    // Id wise action for selected bottom menu items
    override fun onToolSelected(reset: Boolean, id: Int) {
        if (isViewing) {
            return
        }

        if (reset) {
            paintView.selectedTool = null
        }

        findViewById<View>(R.id.shapes).visibility = View.GONE
        findViewById<View>(R.id.colors).visibility = View.GONE
        findViewById<View>(R.id.brushSizeBar).visibility = View.GONE
        when (id) {
            R.id.pen -> {
                paintView.selectedTool = Pen::class.java
                findViewById<MaterialButton>(R.id.selectedTool).setIconResource(R.drawable.ic_tool_pen)
            }

            R.id.colorPicker -> {
//                paintView.selectedTool = EyedropTool::class.java
//                paintView.setOnColorPickedListener(this)
//                findViewById<MaterialButton>(R.id.selectedTool).setIconResource(R.drawable.ic_tool_color_picker)

                findViewById<View>(R.id.colors).visibility = View.VISIBLE
            }

            R.id.red -> {
                paintView.selectedTool = Pen::class.java
                findViewById<MaterialButton>(R.id.selectedTool).setIconResource(R.drawable.ic_tool_pen)
                val color = ContextCompat.getColor(this, R.color.red_900)
                this@MainActivity.onColorPicked(color)
            }

            R.id.black -> {
                paintView.selectedTool = Pen::class.java
                findViewById<MaterialButton>(R.id.selectedTool).setIconResource(R.drawable.ic_tool_pen)
                val color = ContextCompat.getColor(this, R.color.grey_900)
                this@MainActivity.onColorPicked(color)
            }

            R.id.blue -> {
                paintView.selectedTool = Pen::class.java
                findViewById<MaterialButton>(R.id.selectedTool).setIconResource(R.drawable.ic_tool_pen)
                val color = ContextCompat.getColor(this, R.color.blue_900)
                this@MainActivity.onColorPicked(color)
            }

            R.id.shapes -> {
                findViewById<View>(R.id.shapes).visibility = View.VISIBLE
            }
            R.id.rect -> {
                paintView.selectedTool = Quad2D::class.java
                findViewById<MaterialButton>(R.id.selectedTool).setIconResource(R.drawable.ic_shape_rect)
            }
            R.id.circle -> {
                paintView.selectedTool = Circle::class.java
                findViewById<MaterialButton>(R.id.selectedTool).setIconResource(R.drawable.ic_shape_circle)
            }
            R.id.triangle -> {
                paintView.selectedTool = Triangle::class.java
                findViewById<MaterialButton>(R.id.selectedTool).setIconResource(R.drawable.ic_shape_triangle)
            }

            R.id.eraser -> {
                paintView.selectedTool = Eraser::class.java
                findViewById<MaterialButton>(R.id.selectedTool).setIconResource(R.drawable.ic_tool_eraser)
            }
        }

        updatePenColorPicker(paintView.brush.strokeColor)
//        updateFillColorPicker(paintView.brush.fillColor)
    }

    private fun updateFillColorPicker(color: Int) {
        findViewById<MaterialButton>(R.id.selectedTool).backgroundTintList =
            ColorStateList.valueOf(color or 0xFF000000.toInt())
    }

    private fun updatePenColorPicker(color: Int) {
        findViewById<MaterialButton>(R.id.selectedTool).strokeColor = ColorStateList.valueOf(color)
    }

    // touch callbacks over canvas
    override fun onTouch(view: View, motionEvent: MotionEvent): Boolean {
        val selected = paintView.selectedTool
        if (!stickyMaximized && selected != null) {
            when (motionEvent.action) {
                MotionEvent.ACTION_UP -> if (selected != EyedropTool::class.java) {
                    isMaximized = false
                } else {
                    findViewById<View>(R.id.pen).performClick()
                }

                MotionEvent.ACTION_DOWN -> {
                    if (selected != EyedropTool::class.java) {
                        isMaximized = true
                    }

                    view.performClick()
                }
            }
        }
        return false
    }

    // delete project by showing confirmation dialog
    fun deleteProject(view: View) {
        projectName?.let { project ->

            // show dialog
            DialogFactory.confirmDeleteDialog(view.context) {

                // delete project on confirm clicked
                ProjectUtils.delete(project)

                //finish activity
                this@MainActivity.finish()
            }.show(supportFragmentManager)
        }
    }

    @Suppress("UNUSED_PARAMETER")
    fun editMode(view: View) {
        onToggleReadMode(false)
    }

    // create canvas for editing
    private fun createCanvas(metrics: Rect): PaintCanvas {
        val savedDoodle = intent.getStringExtra(PROJECT_FROM_SAVED)
        val selectedImage = intent.getParcelableExtra<Uri>(PROJECT_FROM_IMAGE)

        return if (savedDoodle != null && savedDoodle.isNotEmpty()) {
            projectName = savedDoodle
            resumeProject(metrics, savedDoodle)
        } else if (selectedImage != null) {
            startFromDevice(metrics, selectedImage)
        } else {
            startFromScratch(metrics)
        }
    }


    // initialize paintview, by default pen will select
    private fun initPaintView(canvas: PaintCanvas) {
        paintView.canvas = canvas
        paintView.selectedTool = Pen::class.java  // Select Pen by default
        paintView.brush.size = brushController!!.progress
    }

    private fun onToggleFullscreen(isMaximized: Boolean) {
        findViewById<View>(R.id.editBar).visibility = if (isMaximized) View.GONE else View.VISIBLE
        findViewById<View>(R.id.selectedTool).visibility =
            if (isMaximized) View.GONE else View.VISIBLE
        if (isMaximized) {
            findViewById<View>(R.id.brushSizeBar).visibility = View.GONE
            findViewById<View>(R.id.shapes).visibility = View.GONE
        }
        toolbar.configure(isMaximized)

//        window.decorView.apply {
//            systemUiVisibility = 0
//            systemUiVisibility = if (!isMaximized) {
//                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
//            } else {
//                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
//                } else {
//                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
//                }
//            }
//        }
    }

    // toggle as fullscreen
    private fun onToggleReadMode(isViewing: Boolean) {
        this.isViewing = isViewing
        this.isMaximized = isViewing
        if (isViewing) {
            findViewById<View>(R.id.viewBar).visibility = View.VISIBLE
            paintView.isEnabled = false
            toolbar.secondary.visibility = View.GONE
        } else {
            findViewById<View>(R.id.viewBar).visibility = View.GONE
            paintView.isEnabled = true

            // Select pen
            findViewById<View>(R.id.pen).performClick()
        }
        paintView.invalidate()
    }

    // continuing edit of existing project
    private fun resumeProject(metrics: Rect, savedDoodle: String): PaintCanvas {
        isExisting = true
        return PaintCanvas.createWithBitmapPath(this, metrics, savedDoodle)
    }

    // start existing project
    private fun startFromDevice(metrics: Rect, galleryImage: Uri?): PaintCanvas {
        var canvas: PaintCanvas
        var success = false
        try {
            val path = galleryImage?.path
            val bitmap = BitmapUtils.openFromPath(path!!, metrics.width(), metrics.height())
            canvas = PaintCanvas.createWithBitmap(this, metrics, bitmap!!)

            projectName = path
            success = true
        } catch (ex: Exception) {
            canvas = startFromScratch(metrics)
        } finally {
            val logParams = Bundle()
            logParams.putBoolean(PROPERTY_SUCCESS, success)
        }
        return canvas
    }

    // start new project
    private fun startFromScratch(metrics: Rect): PaintCanvas {
        val canvas = PaintCanvas(this, metrics)

        // Log event
        val logParams = Bundle()
        logParams.putBoolean(PROPERTY_SUCCESS, true)

        return canvas
    }

    // customize toolbar
    private inner class CustomToolbar {
        private val primary: Toolbar = findViewById(R.id.primaryToolbar)
        val secondary: Toolbar

        init {
            primary.overflowIcon = ContextCompat.getDrawable(
                this@MainActivity,
                R.drawable.ic_action_layers
            )
            primary.title = ""

            secondary = findViewById(R.id.secondaryToolbar)
            secondary.title = ""
        }

        fun configure(isMaximized: Boolean) {
            primary.visibility = if (isMaximized) View.GONE else View.VISIBLE
            secondary.visibility = if (!isMaximized) View.GONE else View.VISIBLE
            setSupportActionBar(if (isMaximized) secondary else primary)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)

            val upIcon = ContextCompat.getDrawable(
                ContextThemeWrapper(this@MainActivity, theme),
                when {
                    isMaximized -> R.drawable.ic_action_minimize
                    else -> R.drawable.ic_action_maximize
                }
            )
            upIcon?.colorFilter =
                BlendModeColorFilterCompat.createBlendModeColorFilterCompat(
                    ThemeUtils.colorTextPrimary(this@MainActivity),
                    BlendModeCompat.SRC_ATOP
                )
            supportActionBar?.setHomeAsUpIndicator(upIcon)

        }
    }

}