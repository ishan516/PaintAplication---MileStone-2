package com.adrianalatorre.paintapp.helper.models.shapes

import android.graphics.PointF
import com.adrianalatorre.paintapp.helper.models.PaintBrush
import com.adrianalatorre.paintapp.helper.models.Tool
import kotlin.math.abs


class Circle internal constructor(paintBrush: PaintBrush) : Tool(paintBrush) {

    override fun draw(i: PointF, f: PointF) {
        // Find midpoint
        val x = (i.x + f.x) / 2
        val y = (i.y + f.y) / 2

        // Calculate radius
        val xr = abs((f.x - i.x) / 2)
        val yr = abs((f.y - i.y) / 2)
        val r = if (xr > yr) xr else yr

        // Add circle to path
        this.reset()
        this.moveTo(i.x, i.y)
        this.addCircle(x, y, r, Direction.CW)
    }
}
