package com.adrianalatorre.paintapp.helper

import android.content.Intent
import android.view.View
import android.widget.AdapterView
import android.widget.GridView
import androidx.annotation.UiThread
import androidx.appcompat.app.AppCompatActivity
import com.adrianalatorre.paintapp.MainActivity
import com.adrianalatorre.paintapp.MyApplication.Companion.DEFAULT_PROJECT_NAME
import com.adrianalatorre.paintapp.MyApplication.Companion.FLAG_READ_ONLY
import com.adrianalatorre.paintapp.MyApplication.Companion.PROJECT_FROM_SAVED
import com.adrianalatorre.paintapp.R
import com.adrianalatorre.paintapp.helper.adapter.ProjectAdapter
import com.adrianalatorre.paintapp.helper.models.Project
import com.adrianalatorre.paintapp.utils.ProjectUtils
import java.util.*



/*
*
* A wrapper class which will load all saved projects into UI thread from project database
*
* */
@UiThread
class ProjectInflater(private val activity: AppCompatActivity) : Runnable, AdapterView.OnItemClickListener {

    // fetch all projects from cache
    private val projects: ArrayList<Project>
        get() {
            val projects = ArrayList<Project>()

            // load from dtatabase, see @ProjectUtils
            ProjectUtils.listAll()?.forEach { projectName ->
                var project = ProjectUtils[projectName]
                if (project == null) {
                    project = Project()
                    project.name = DEFAULT_PROJECT_NAME
                    project.timestamp = ProjectUtils.name2Timestamp(projectName)

                    ProjectUtils[ProjectUtils.name2Timestamp(projectName)] = project
                }

                projects.add(project)
            }
            return projects
        }

    // inflate all project views into ProjectAdapter as Grid
    private fun inflate() {
        val projects = projects
        val adapter = ProjectAdapter(
                activity,
                R.layout.view_project,
                projects)

        val projectGrid = activity.findViewById<GridView>(R.id.savedProjectsGrid)
        projectGrid.adapter = adapter
        projectGrid.onItemClickListener = this
    }

    override fun run() {
        inflate()
    }

    // open or view selected project
    override fun onItemClick(parent: AdapterView<*>, view: View, position: Int, id: Long) {
        val intent = Intent(activity, MainActivity::class.java)
        val item = parent.getItemAtPosition(position) as Project
        intent.putExtra(PROJECT_FROM_SAVED, item.timestamp)
        intent.putExtra(FLAG_READ_ONLY, true)

        if (item.timestamp!! !in ProjectUtils) return

        activity.startActivity(intent)
    }

}