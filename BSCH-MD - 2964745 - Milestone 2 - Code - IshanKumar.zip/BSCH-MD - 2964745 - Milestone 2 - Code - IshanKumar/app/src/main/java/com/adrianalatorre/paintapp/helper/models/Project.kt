package com.adrianalatorre.paintapp.helper.models

class Project {

    var uploader: String? = null
    var name: String? = null
    var timestamp: String? = null
    var likes: Int? = 0
    var reposts: Int? = 0

}