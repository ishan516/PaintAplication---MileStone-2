package com.adrianalatorre.paintapp.helper.models

import android.graphics.PointF

class EyedropTool internal constructor(paintBrush: PaintBrush) : Tool(paintBrush) {

    override fun draw(i: PointF, f: PointF) {

    }

}