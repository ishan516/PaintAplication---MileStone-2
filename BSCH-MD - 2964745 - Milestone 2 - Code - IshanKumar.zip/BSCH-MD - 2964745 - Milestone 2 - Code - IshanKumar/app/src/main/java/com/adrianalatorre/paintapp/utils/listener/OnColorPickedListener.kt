package com.adrianalatorre.paintapp.utils.listener

import com.adrianalatorre.paintapp.PaintView

/**
 * OnColorPickedListener provides a callback interface for certain actions performed on the [PaintView].
 *
 */
interface OnColorPickedListener {

    fun onColorPicked(color: Int)

}
