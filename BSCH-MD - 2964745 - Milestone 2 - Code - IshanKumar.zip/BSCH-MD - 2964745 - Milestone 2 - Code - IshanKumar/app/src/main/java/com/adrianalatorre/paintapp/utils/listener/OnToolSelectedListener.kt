package com.adrianalatorre.paintapp.utils.listener



/**
 * OnToolSelectedListener provides a callback interface for certain actions performed on the [MainActivity].
 *
 */
interface OnToolSelectedListener {
    fun onToolSelected(reset: Boolean, id: Int)

}
