package com.adrianalatorre.paintapp.helper.factory

import android.content.Context
import com.adrianalatorre.paintapp.R
import com.adrianalatorre.paintapp.utils.listener.OnSuccessListener
import com.adrianalatorre.paintapp.helper.views.dialog.OptionsDialog


/*
*
* Dialog wrapper class which contains all type of user action confirmation
*
* */
object DialogFactory {
    fun confirmDeleteDialog(context: Context, yes: OnSuccessListener<Void>): OptionsDialog {
        return OptionsDialog.Builder()
            .addOption(context.resources.getString(R.string.label_delete),
                context.resources.getString(R.string.confirm_delete_body),
                R.drawable.ic_action_delete) { dialog, _ ->
                yes.onSuccess(null)
                dialog.dismiss()
            }
            .create()
    }

    fun confirmExitDialog(context: Context, yes: OnSuccessListener<Void>, no: OnSuccessListener<Void>): OptionsDialog {
        return OptionsDialog.Builder()
            .addOption(context.resources.getString(R.string.label_close),
                context.resources.getString(R.string.desc_prompt_close),
                R.drawable.ic_tool_eraser) { dialog, _ ->
                yes.onSuccess(null)
                dialog.dismiss()
            }
            .addOption(context.resources.getString(R.string.label_save_and_close),
                context.resources.getString(R.string.desc_prompt_save_and_close),
                R.drawable.ic_action_save) { dialog, _ ->
                no.onSuccess(null)
                dialog.dismiss()
            }
            .create()
    }

    fun confirmRevertDialog(context: Context, yes: OnSuccessListener<Void>): OptionsDialog {
        return OptionsDialog.Builder()
            .addOption(context.resources.getString(R.string.menu_action_revert),
                context.resources.getString(R.string.desc_prompt_revert),
                R.drawable.ic_action_revert) { dialog, _ ->
                yes.onSuccess(null)
                dialog.dismiss()
            }
            .create()
    }

    fun confirmSaveDialog(context: Context, yes: OnSuccessListener<Void>): OptionsDialog {
        return OptionsDialog.Builder()
            .addOption(context.resources.getString(R.string.menu_action_save),
                context.getString(R.string.desc_prompt_save),
                R.drawable.ic_action_save) { dialog, _ ->
                yes.onSuccess(null)
                dialog.dismiss()
            }
            .create()
    }

}