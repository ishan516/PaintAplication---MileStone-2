package com.adrianalatorre.paintapp.helper.adapter

import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.adrianalatorre.paintapp.helper.models.Project
import com.adrianalatorre.paintapp.helper.views.utils.ProjectView

/*
*
* Inflater for project items
*
* */
class ProjectAdapter internal constructor(private val context: AppCompatActivity, private val gridLayoutId: Int, private val projects: List<Project>) : ArrayAdapter<Project>(context, gridLayoutId, projects) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var gridItem = convertView
        val projectView: ProjectView
        if (gridItem == null) {
            val inflater = context.layoutInflater
            gridItem = inflater.inflate(gridLayoutId, parent, false)

            projectView = ProjectView(gridItem)
            gridItem.tag = projectView
        } else {
            projectView = gridItem.tag as ProjectView
        }

        projectView.show(projects[position])
        return gridItem!!
    }

}