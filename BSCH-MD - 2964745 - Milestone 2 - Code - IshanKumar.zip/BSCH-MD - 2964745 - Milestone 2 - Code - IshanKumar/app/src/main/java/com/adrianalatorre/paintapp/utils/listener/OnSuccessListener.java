package com.adrianalatorre.paintapp.utils.listener;


/**
 * OnSuccessListener provides a callback interface for certain actions performed on the [DialogFactory].
 *
 */
public interface OnSuccessListener<TResult> {
    void onSuccess(TResult var1);
}
