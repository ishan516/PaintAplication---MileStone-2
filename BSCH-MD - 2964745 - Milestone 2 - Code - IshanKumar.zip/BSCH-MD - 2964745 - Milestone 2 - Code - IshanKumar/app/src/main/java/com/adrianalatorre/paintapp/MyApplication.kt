package com.adrianalatorre.paintapp

import android.app.Application
import com.orhanobut.hawk.Hawk
import com.adrianalatorre.paintapp.utils.ProjectUtils

/**
 * MyApplication is the Application class which bootstraps everything and initializes the global
 * state of the app.
 *
 */
class MyApplication : Application() {

    /**
     * Called when the application is starting, before any other application objects
     * are created. Used for initial configuration.
     */
    override fun onCreate() {
        super.onCreate()
        Hawk.init(this).build()
        ProjectUtils.init(this)
    }

    companion object {

        // Defaults
        const val DEFAULT_PROJECT_NAME = "Untitled"
        const val EXT_IMAGE = ".jpg"
        const val EXT_IMAGE_MIME = "image/jpeg"
        const val EXT_METADATA = ".json"

        // Events
        const val EVENT_PROJECT_CREATE = "from_device"
        const val EVENT_PROJECT_CREATE_BLANK = "from_scratch"

        // Properties
        const val PROPERTY_SUCCESS = "success"

        // Flags
        const val FLAG_READ_ONLY = "READ_ONLY"

        // Project properties
        const val PROJECT_FROM_IMAGE = "FROM_DEVICE"
        const val PROJECT_FROM_SAVED = "DOODLE"

        // Tags
        const val TAG_THEME = "APP_THEME"
    }

}