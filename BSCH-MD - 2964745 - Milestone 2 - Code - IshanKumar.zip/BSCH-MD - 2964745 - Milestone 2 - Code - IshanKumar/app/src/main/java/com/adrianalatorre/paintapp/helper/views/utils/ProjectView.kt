package com.adrianalatorre.paintapp.helper.views.utils

import android.graphics.Bitmap
import android.view.View
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.adrianalatorre.paintapp.R
import com.adrianalatorre.paintapp.helper.models.Project
import com.adrianalatorre.paintapp.utils.ProjectUtils
import java.io.ByteArrayOutputStream

/*
*
*  A custom ViewHolder class which shows saved project details
* */
class ProjectView(itemView: View) : RecyclerView.ViewHolder(itemView) {

    private val iconView: ImageView = itemView.findViewById(R.id.projectIcon)
    private val nameView: TextView = itemView.findViewById(R.id.projectName)

    // initialize all fields
    fun show(project: Project) {
        nameView.text = project.name
        nameView.visibility = View.GONE

        project.timestamp?.let {
            val stream = ByteArrayOutputStream()
            ProjectUtils.open(it, 128, 128)?.compress(Bitmap.CompressFormat.JPEG, 100, stream)
            Glide.with(iconView.context)
                    .load(stream.toByteArray())
                    .into(iconView)
        }
    }

}