package com.adrianalatorre.paintapp

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.PointF
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import com.adrianalatorre.paintapp.helper.factory.ToolFactory
import com.adrianalatorre.paintapp.helper.models.*
import com.adrianalatorre.paintapp.helper.models.shapes.Eraser
import com.adrianalatorre.paintapp.utils.listener.CanvasActionListener
import com.adrianalatorre.paintapp.utils.listener.OnColorPickedListener


/*
*
*  A class which will allow to draw painting over canvas
*
*
* */
class PaintView : View {

    // Custom Brash to paint or draw
    val brush: PaintBrush

    // Custom Canvas for painting
    var canvas: PaintCanvas? = null

    // Selected function by user
    var selectedTool: Class<out Tool>? = null

    // A helper for redo, undo, revert and track pointer of draw points
    private val tools = Tools()

    // start touch point
    private val iTouch = PointF()

    //end touch point
    private var fTouch: PointF? = PointF()

    // Action callbacks
    private var canvasActionListener: CanvasActionListener? = null
    private var onColorPickedListener: OnColorPickedListener? = null

    // check if any action is taken over canvas
    val isModified: Boolean
        get() = tools.pointer > 0

    constructor(context: Context) : super(context) {
        brush = PaintBrush(context)
    }

    constructor(context: Context, attrs: AttributeSet) : super(context, attrs) {
        brush = PaintBrush(context)
    }

    override fun onDraw(canvas: Canvas) {
        canvas.save()
        this.canvas?.let {
            it.drawBackground()
            it.drawPaths(tools)

            canvas.drawBitmap(it.bitmap, 0f, 0f, null)
        }
        canvas.restore()
    }

    //setting up the touch events

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(ev: MotionEvent): Boolean {
        if (selectedTool == null || !isEnabled || ev.pointerCount > 1) return false
        val touchAt = PointF(ev.x, ev.y)

        when (ev.action) {
            MotionEvent.ACTION_DOWN -> {
                touchStart(touchAt)
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                touchMove(touchAt)
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> {
                touchUp(touchAt)
                performClick()
                invalidate()
                return true
            }
        }

        return false
    }

    //check if can redo or not
    fun canRedo(): Boolean {
        return tools.pointer < tools.size
    }

    // clear or revert all
    fun clear() {
        tools.clear()
        invalidate()

        canvasActionListener?.onRevert()
    }

    // redo action
    fun redo() {
        val canRedo = tools.redo()
        invalidate()

        canvasActionListener?.onRedo(canRedo)
    }

    fun setCanvasActionListener(canvasActionListener: CanvasActionListener) {
        this.canvasActionListener = canvasActionListener
    }

    fun setOnColorPickedListener(onColorPickedListener: OnColorPickedListener) {
        this.onColorPickedListener = onColorPickedListener
    }

    // project save function
    fun save() {
        canvas?.saveProject()
    }

    // undo action
    fun undo() {
        val canUndo = tools.undo()
        invalidate()

        canvasActionListener?.onUndo(canUndo)
    }

    private fun touchStart(touchAt: PointF) {
        if (this.selectedTool == EyedropTool::class.java) {
            canvas?.let {
                val color = it.getColor(touchAt)
                this.onColorPickedListener?.onColorPicked(color)
                return
            }
        }

        iTouch.set(touchAt)
        fTouch = null
    }

    private fun touchMove(touchAt: PointF) {
        if (this.selectedTool == EyedropTool::class.java) {
            canvas?.let {
                val color = it.getColor(touchAt)
                this.onColorPickedListener?.onColorPicked(color)
                return
            }
        }

        if (fTouch == null) {
            fTouch = PointF()

            val tool = ToolFactory[selectedTool!!, brush]
            tool!!.moveTo(iTouch.x, iTouch.y)
            if (tool.javaClass == Eraser::class.java) {
                canvas?.let { (tool as Eraser).initEraser(it) }
            }
            tools.add(tool)
        }

        fTouch?.let {
            val dx = Math.abs(touchAt.x - it.x)
            val dy = Math.abs(touchAt.y - it.y)
            if (dx < TOUCH_TOLERANCE && dy < TOUCH_TOLERANCE) {
                return
            }

            it.set(touchAt)
            tools.current?.draw(iTouch, it)
        }
    }

    private fun touchUp(touchAt: PointF) {
        canvas?.let { c ->
            if (this.selectedTool == EyedropTool::class.java) {
                val color = c.getColor(touchAt)
                this.onColorPickedListener?.onColorPicked(color)
                return
            }

            if (fTouch == null) {
                fTouch = touchAt
                val tool = ToolFactory[selectedTool!!, brush]
                tool!!.moveTo(touchAt.x, touchAt.y)
                if (tool.javaClass == Eraser::class.java) {
                    (tool as Eraser).initEraser(c)
                }
                tools.add(tool)
            }

            fTouch?.let {
                val currentTool = tools.current
                currentTool?.draw(iTouch, it)
                canvasActionListener?.onDrawPath()
            }
        }
    }

    companion object {
        private const val TOUCH_TOLERANCE = 5f
    }

}